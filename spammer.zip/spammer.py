import time
from pynput import keyboard
from pynput.keyboard import Controller
from threading import Thread

# Initialize a controller for typing
keyboard_controller = Controller()

# Flags to track state
is_typing = False

# change type_q to type_ and then the key you want pressed
def type_q():
    while is_typing:
        keyboard_controller.press('q')
        keyboard_controller.release('q')
        time.sleep(0.2)  # change 0.2 to anything 0.2 = 5 times per second

def on_press(key):
    global is_typing

    try:
        # Check if the pressed key is 'y' and typing is not active
        if key.char == 'y' and not is_typing:
            print("Detected Y, starting to type Q at 5 times per second.")
            is_typing = True
            typing_thread = Thread(target=type_q)
            typing_thread.daemon = True
            typing_thread.start()

        elif key.char == 'k' and is_typing:
            print("Detected K, stopping typing and exiting.")
            is_typing = False
            return False

    except AttributeError:
        pass

def on_release(key):
    pass

with keyboard.Listener(on_press=on_press, on_release=on_release) as listener:
    listener.join()
