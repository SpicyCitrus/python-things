from pynput.mouse import Button, Controller as MouseController
from pynput.keyboard import Listener, KeyCode
import threading
import time

while True:
    try:
        clicks_per_second = float(input("Enter clicks per second (example, 10): "))
        if clicks_per_second <= 0:
            print("Please enter a positive number.")
        else:
            break
    except ValueError:
        print("Invalid input. Please enter a number.")

START_KEY = KeyCode(char='p')
STOP_KEY = KeyCode(char='k')

clicking = False
program_running = True

mouse = MouseController()

def clicker():
    global clicking
    while program_running:
        if clicking:
            mouse.click(Button.left)
            time.sleep(1 / clicks_per_second)
        else:
            time.sleep(0.1)

def on_press(key):
    global clicking, program_running

    if key == START_KEY:
        clicking = True
        print("AutoClicker started. Press 'k' to stop.")
    elif key == STOP_KEY:
        clicking = False
        program_running = False
        print("AutoClicker stopped.")
        return False  

click_thread = threading.Thread(target=clicker)
click_thread.start()

with Listener(on_press=on_press) as listener:
    listener.join()