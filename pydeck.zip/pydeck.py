import tkinter as tk
from tkinter import filedialog, colorchooser, messagebox
import subprocess
import json
import os

CONFIG_FILE = "config.json"

class ScriptControlPanel:
    def __init__(self, root):
        self.root = root
        self.root.title("Cozy's PYDeck")
        self.root.configure(bg="#1e1e1e")  
        self.scripts = []

        self.load_config()

        self.main_frame = tk.Frame(root, bg="#1e1e1e")
        self.main_frame.pack(fill="both", expand=True)

        self.settings_frame = tk.Frame(root, bg="#1e1e1e")
        self.settings_frame.pack_forget()

        self.create_top_bar()
        self.create_buttons()
        self.create_settings_tab()

    def load_config(self):
        if not os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'w') as f:
                json.dump({"buttons": []}, f)
        with open(CONFIG_FILE, 'r') as f:
            config = json.load(f)
        self.scripts = config.get("buttons", [])

        for script in self.scripts:
            script["label"] = os.path.splitext(script["label"])[0]

        self.save_config()

    def save_config(self):
        with open(CONFIG_FILE, 'w') as f:
            json.dump({"buttons": self.scripts}, f, indent=4)

    def create_top_bar(self):
        top_bar = tk.Frame(self.main_frame, bg="#1e1e1e")
        top_bar.pack(fill="x", pady=10, padx=10)
        
        settings_btn = tk.Button(
            top_bar,
            text="⚙️",
            command=self.show_settings,
            bg="#1e1e1e",
            fg="white",
            border=0,
            font=("Arial", 14)
        )
        settings_btn.pack(side="right")

    def create_buttons(self):
        self.button_frame = tk.Frame(self.main_frame, bg="#1e1e1e")
        self.button_frame.pack(pady=10)

        for script in self.scripts:
            self.add_script_button(script)

    def refresh_buttons(self):
        for widget in self.button_frame.winfo_children():
            widget.destroy()
        for script in self.scripts:
            self.add_script_button(script)

    def add_script_button(self, script):
        btn = tk.Button(
            self.button_frame,
            text=script["label"],
            command=lambda path=script["path"]: self.run_script(path),
            bg=script.get("color", "#000000"), 
            fg="white",
            font=("Arial", 12),
            padx=20,
            pady=10
        )
        btn.pack(pady=5, fill="x", padx=20)

    def run_script(self, path):
        if os.path.exists(path):
            subprocess.Popen(["python", path])
        else:
            messagebox.showerror("Error", f"Script not found:\n{path}")

    def show_main(self):
        self.settings_frame.pack_forget()
        self.main_frame.pack(fill="both", expand=True)
        self.refresh_buttons()

    def show_settings(self):
        self.main_frame.pack_forget()
        self.settings_frame.pack(fill="both", expand=True)
        self.refresh_settings()

    def create_settings_tab(self):
        self.settings_title = tk.Label(
            self.settings_frame, text="Settings", font=("Arial", 16),
            bg="#1e1e1e", fg="white"
        )
        self.settings_title.pack(pady=10)

        self.add_button = tk.Button(
            self.settings_frame, text="Add Script", command=self.add_new_script,
            bg="#000000", fg="white", padx=10, pady=5
        )
        self.add_button.pack(pady=5)

        self.reorder_button = tk.Button(
            self.settings_frame, text="Reorder Buttons", command=self.toggle_reorder_mode,
            bg="#000000", fg="white", padx=10, pady=5
        )
        self.reorder_button.pack(pady=5)

        self.back_button = tk.Button(
            self.settings_frame, text="Back", command=self.show_main,
            bg="#000000", fg="white", padx=10, pady=5
        )
        self.back_button.pack(pady=5)

        self.reorder_mode = False
        self.settings_list_frame = tk.Frame(self.settings_frame, bg="#1e1e1e")
        self.settings_list_frame.pack(pady=10)

    def refresh_settings(self):
        for widget in self.settings_list_frame.winfo_children():
            widget.destroy()

        for i, script in enumerate(self.scripts):
            frame = tk.Frame(self.settings_list_frame, bg="#1e1e1e")
            frame.pack(fill="x", padx=20, pady=2)

            tk.Label(frame, text=script["label"], bg="#1e1e1e", fg="white").pack(side="left")

            tk.Button(
                frame, text="Color", command=lambda i=i: self.change_color(i),
                bg=script.get("color", "#000000"), fg="white", padx=5
            ).pack(side="left", padx=5)

            if self.reorder_mode:
                if i > 0:
                    tk.Button(
                        frame, text="↑", command=lambda i=i: self.move_up(i),
                        bg="#2a2a2a", fg="white", padx=5
                    ).pack(side="right")
                if i < len(self.scripts) - 1:
                    tk.Button(
                        frame, text="↓", command=lambda i=i: self.move_down(i),
                        bg="#2a2a2a", fg="white", padx=5
                    ).pack(side="right")

    def add_new_script(self):
        filepath = filedialog.askopenfilename(
            title="Select Python Script", filetypes=[("Python Files", "*.py")]
        )
        if filepath:
            name = os.path.splitext(os.path.basename(filepath))[0]
            color = "#000000" 
            self.scripts.append({"label": name, "path": filepath, "color": color})
            self.save_config()
            self.refresh_settings()

    def change_color(self, index):
        color = colorchooser.askcolor()[1]
        if color:
            self.scripts[index]["color"] = color
            self.save_config()
            self.refresh_settings()

    def toggle_reorder_mode(self):
        self.reorder_mode = not self.reorder_mode
        self.refresh_settings()

    def move_up(self, index):
        self.scripts[index - 1], self.scripts[index] = self.scripts[index], self.scripts[index - 1]
        self.save_config()
        self.refresh_settings()

    def move_down(self, index):
        self.scripts[index + 1], self.scripts[index] = self.scripts[index], self.scripts[index + 1]
        self.save_config()
        self.refresh_settings()


if __name__ == "__main__":
    root = tk.Tk()
    app = ScriptControlPanel(root)
    root.geometry("500x600")
    root.mainloop()




# claim this as your own if you are weird, make with love by cozytorch.